const CommunityPost = require('../models/CommunityPost');
const crisisService = require('../services/crisisService');

// Generate a safe animal alias for anonymity
const ANIMALS = ['Sparrow','Fox','Owl','Deer','Bear','Wolf','Crane','Panda','Lynx','Finch'];
const ADJECTIVES = ['Calm','Gentle','Brave','Quiet','Warm','Kind','Bold','Soft','Still'];
const generateAlias = () => {
  const adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
  const animal = ANIMALS[Math.floor(Math.random() * ANIMALS.length)];
  const num = Math.floor(Math.random() * 90) + 10;
  return `${adj} ${animal} #${num}`;
};

// @route  GET /api/community/posts
const getPosts = async (req, res) => {
  const { tag, category, page = 1, limit = 20 } = req.query;
  const filter = { isHidden: false };
  if (tag) filter.tags = tag;
  if (category) filter.category = category;

  const posts = await CommunityPost.find(filter)
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .select('-user'); // never expose real user ID

  res.json({ posts });
};

// @route  POST /api/community/posts
const createPost = async (req, res) => {
  const { content, mood, tags, category } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Content is required.' });
  if (content.length > 800) return res.status(400).json({ error: 'Post too long (max 800 chars).' });

  // Crisis check — if critical, redirect to help instead of posting
  const crisis = await crisisService.detectCrisis(content);
  if (crisis.level === 'critical') {
    return res.status(200).json({
      blocked: true,
      crisis: {
        message: crisis.response.message,
        calmMode: crisisService.getCalmModeContent(),
      },
    });
  }

  const post = await CommunityPost.create({
    user: req.user._id,
    alias: generateAlias(),
    content,
    mood,
    tags,
    category,
  });

  // Don't return user field
  const safe = post.toObject();
  delete safe.user;

  res.status(201).json({ post: safe });
};

// @route  POST /api/community/posts/:id/hug
const sendHug = async (req, res) => {
  const post = await CommunityPost.findByIdAndUpdate(
    req.params.id,
    { $inc: { hugs: 1 } },
    { new: true }
  );
  res.json({ hugs: post.hugs });
};

// @route  POST /api/community/posts/:id/reply
const addReply = async (req, res) => {
  const { content } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Reply cannot be empty.' });

  const crisis = await crisisService.detectCrisis(content);

  const post = await CommunityPost.findByIdAndUpdate(
    req.params.id,
    { $push: { replies: { user: req.user._id, alias: generateAlias(), content } } },
    { new: true }
  );

  res.json({
    replies: post.replies,
    crisis: crisis.detected ? { level: crisis.level, message: crisis.response.message } : null,
  });
};

module.exports = { getPosts, createPost, sendHug, addReply };
