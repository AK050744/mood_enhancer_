// recommendationController.js
const Recommendation = require('../models/Recommendation');

const getRecommendations = async (req, res) => {
  const { type, limit = 20 } = req.query;
  const filter = { user: req.user._id };
  if (type) filter.type = type;

  const recs = await Recommendation.find(filter)
    .sort({ createdAt: -1 })
    .limit(parseInt(limit));
  res.json({ recommendations: recs });
};

const submitFeedback = async (req, res) => {
  const { liked, consumed, helpedMood } = req.body;
  const rec = await Recommendation.findOneAndUpdate(
    { _id: req.params.id, user: req.user._id },
    { feedback: { liked, consumed, helpedMood, ratedAt: new Date() } },
    { new: true }
  );
  if (!rec) return res.status(404).json({ error: 'Not found.' });

  // If they disliked it, add to user's disliked content
  if (liked === false) {
    const User = require('../models/User');
    await User.findByIdAndUpdate(req.user._id, {
      $addToSet: { 'preferences.dislikedContent': rec.title },
    });
  }

  res.json({ recommendation: rec });
};

module.exports = { getRecommendations, submitFeedback };
