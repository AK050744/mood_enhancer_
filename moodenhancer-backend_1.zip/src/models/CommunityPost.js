const mongoose = require('mongoose');

const communityPostSchema = new mongoose.Schema({
  // No direct user reference displayed — anonymity is core
  user:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  alias:   { type: String, required: true }, // "Calm Sparrow #42" — auto-generated

  content: { type: String, required: true, maxlength: 800 },
  mood:    { type: Number, min: 1, max: 10 },
  tags:    [String], // ["anxiety", "exam-stress", "loneliness"]
  category:{ type: String, enum: ['venting', 'seeking_advice', 'sharing_win', 'gratitude'] },

  // Support reactions (not likes — designed for empathy)
  hugs:      { type: Number, default: 0 },
  meTooPosts:{ type: Number, default: 0 }, // "me too" button

  replies: [{
    user:      { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    alias:     String,
    content:   { type: String, maxlength: 400 },
    createdAt: { type: Date, default: Date.now },
  }],

  // Safety
  isModerated: { type: Boolean, default: false },
  isFlagged:   { type: Boolean, default: false },
  isHidden:    { type: Boolean, default: false },

}, { timestamps: true });

communityPostSchema.index({ createdAt: -1 });
communityPostSchema.index({ tags: 1 });

module.exports = mongoose.model('CommunityPost', communityPostSchema);
