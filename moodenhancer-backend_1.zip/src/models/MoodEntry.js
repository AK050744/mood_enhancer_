const mongoose = require('mongoose');

const moodEntrySchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true,
  },

  // Raw input from the user
  rawText: {
    type: String,
    maxlength: [2000, 'Entry too long'],
  },
  moodScore: {
    type: Number,
    min: 1,
    max: 10,
    required: true,
  },

  // What the user selected (quick labels)
  selectedEmotions: [{
    type: String,
    enum: [
      'happy', 'calm', 'excited', 'grateful',
      'sad', 'anxious', 'angry', 'stressed',
      'lonely', 'hopeless', 'overwhelmed', 'confused',
      'numb', 'tired', 'motivated', 'loved'
    ],
  }],

  // AI analysis result
  aiAnalysis: {
    primaryEmotion: String,
    emotionScores: {
      joy:       { type: Number, default: 0 },
      sadness:   { type: Number, default: 0 },
      anxiety:   { type: Number, default: 0 },
      anger:     { type: Number, default: 0 },
      stress:    { type: Number, default: 0 },
      loneliness:{ type: Number, default: 0 },
      hope:      { type: Number, default: 0 },
    },
    themes: [String], // e.g. ["exam pressure", "friendship issues"]
    sentiment: { type: String, enum: ['positive', 'neutral', 'negative'] },
    summary: String, // 1-line AI summary
  },

  // CRISIS DETECTION — most important field
  crisisDetected: {
    type: Boolean,
    default: false,
    index: true,
  },
  crisisLevel: {
    type: String,
    enum: ['none', 'low', 'medium', 'high', 'critical'],
    default: 'none',
  },
  crisisKeywords: [String], // which phrases triggered detection
  crisisAcknowledged: { type: Boolean, default: false },

  // Context
  context: {
    sleepHours: { type: Number, min: 0, max: 24 },
    exercisedToday: Boolean,
    socialInteraction: { type: String, enum: ['none', 'little', 'moderate', 'lots'] },
    stressors: [String], // ["exams", "family", "money", "relationships"]
  },

  // Recommendations generated for this entry
  recommendations: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Recommendation',
  }],

  // Did the user feel better after consuming recommendations?
  followUpScore: { type: Number, min: 1, max: 10 },
  followUpAt: Date,

}, { timestamps: true });

// Index for analytics queries
moodEntrySchema.index({ user: 1, createdAt: -1 });
moodEntrySchema.index({ crisisDetected: 1, crisisAcknowledged: 1 });

module.exports = mongoose.model('MoodEntry', moodEntrySchema);
