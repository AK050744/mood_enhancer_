const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxlength: [60, 'Name cannot exceed 60 characters'],
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email'],
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters'],
    select: false,
  },
  age: { type: Number, min: 13, max: 25 },
  gender: { type: String, enum: ['male', 'female', 'non-binary', 'prefer_not_to_say'] },
  language: { type: String, enum: ['en', 'hi', 'mr'], default: 'en' },

  // Preferences learned over time
  preferences: {
    contentTypes: { type: [String], default: ['movies', 'music', 'podcasts', 'games', 'audiobooks'] },
    genres: { type: [String], default: [] },
    dislikedContent: { type: [String], default: [] },
  },

  // AI memory — rolling summary of user's emotional patterns
  aiMemory: {
    summary: { type: String, default: '' }, // GPT-generated rolling summary
    dominantEmotions: { type: [String], default: [] },
    triggers: { type: [String], default: [] }, // what makes them stressed
    helpers: { type: [String], default: [] }, // what has helped them
    lastUpdated: { type: Date },
  },

  // Streak & engagement
  streak: { type: Number, default: 0 },
  lastActiveDate: { type: Date },
  totalCheckIns: { type: Number, default: 0 },

  // Safety
  crisisCount: { type: Number, default: 0 },
  lastCrisisAt: { type: Date },

  isActive: { type: Boolean, default: true },
  role: { type: String, enum: ['user', 'admin', 'counselor'], default: 'user' },

}, { timestamps: true });

// Hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, parseInt(process.env.BCRYPT_ROUNDS) || 12);
  next();
});

userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Update streak on login
userSchema.methods.updateStreak = function () {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const last = this.lastActiveDate ? new Date(this.lastActiveDate) : null;
  if (last) last.setHours(0, 0, 0, 0);

  if (!last || (today - last) > 86400000 * 1.5) {
    this.streak = 1;
  } else if ((today - last) > 0) {
    this.streak += 1;
  }
  this.lastActiveDate = new Date();
};

module.exports = mongoose.model('User', userSchema);
