const { v4: uuidv4 } = require('uuid');
const ChatMessage = require('../models/ChatMessage');
const User = require('../models/User');
const openaiService = require('../services/openaiService');
const crisisService = require('../services/crisisService');

// @route  POST /api/chat/message
const sendMessage = async (req, res) => {
  const { content, sessionId } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Message cannot be empty.' });

  const user = await User.findById(req.user._id);
  const sid = sessionId || uuidv4();

  // Check for crisis in message
  const crisisResult = await crisisService.detectCrisis(content);

  // Save user message
  await ChatMessage.create({
    user: user._id,
    role: 'user',
    content,
    sessionId: sid,
    crisisFlag: crisisResult.detected,
  });

  // Get last 12 messages for context
  const history = await ChatMessage.find({ user: user._id, sessionId: sid })
    .sort({ createdAt: -1 })
    .limit(12)
    .lean();

  const conversationHistory = history
    .reverse()
    .slice(0, -1) // exclude the message we just saved
    .map(m => ({ role: m.role, content: m.content }));

  // Get AI response
  let aiContent;
  if (crisisResult.detected && crisisResult.level !== 'low') {
    // For medium+ crisis, prepend the crisis response to Mia's reply
    aiContent = crisisResult.response.message;
  } else {
    aiContent = await openaiService.chatResponse(
      content,
      conversationHistory,
      user.aiMemory,
      user.name
    );
  }

  // Save AI response
  const aiMessage = await ChatMessage.create({
    user: user._id,
    role: 'assistant',
    content: aiContent,
    sessionId: sid,
    crisisFlag: crisisResult.detected,
  });

  res.json({
    message: { id: aiMessage._id, content: aiContent, role: 'assistant', createdAt: aiMessage.createdAt },
    sessionId: sid,
    crisis: crisisResult.detected ? {
      level: crisisResult.level,
      calmMode: crisisResult.level !== 'low' ? crisisService.getCalmModeContent() : null,
    } : null,
  });
};

// @route  GET /api/chat/history/:sessionId
const getChatHistory = async (req, res) => {
  const { sessionId } = req.params;
  const messages = await ChatMessage.find({ user: req.user._id, sessionId })
    .sort({ createdAt: 1 })
    .limit(50);
  res.json({ messages });
};

// @route  GET /api/chat/sessions
const getSessions = async (req, res) => {
  const sessions = await ChatMessage.aggregate([
    { $match: { user: req.user._id } },
    { $sort: { createdAt: -1 } },
    { $group: { _id: '$sessionId', lastMessage: { $first: '$content' }, lastAt: { $first: '$createdAt' }, count: { $sum: 1 } } },
    { $sort: { lastAt: -1 } },
    { $limit: 20 },
  ]);
  res.json({ sessions });
};

module.exports = { sendMessage, getChatHistory, getSessions };
