const mongoose = require('mongoose');

const journalSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, maxlength: 120 },
  content: { type: String, required: true, maxlength: 5000 },
  mood: { type: Number, min: 1, max: 10 },
  tags: [String],
  isPrivate: { type: Boolean, default: true },

  // AI reflection generated for this entry
  aiReflection: {
    message: String,     // empathetic response from AI
    insight: String,     // pattern it noticed
    suggestion: String,  // one actionable thing
    generatedAt: Date,
  },
}, { timestamps: true });

journalSchema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model('Journal', journalSchema);
