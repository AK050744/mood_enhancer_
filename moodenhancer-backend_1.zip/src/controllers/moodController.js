const MoodEntry = require('../models/MoodEntry');
const User = require('../models/User');
const Recommendation = require('../models/Recommendation');
const openaiService = require('../services/openaiService');
const crisisService = require('../services/crisisService');
const externalApiService = require('../services/externalApiService');
const logger = require('../utils/logger');

// @route  POST /api/mood/checkin
// This is the main entry point — user submits their mood
const checkIn = async (req, res) => {
  const { rawText, moodScore, selectedEmotions, context } = req.body;
  const user = await User.findById(req.user._id);

  if (!moodScore || moodScore < 1 || moodScore > 10) {
    return res.status(400).json({ error: 'Mood score must be between 1 and 10.' });
  }

  // ── 1. Crisis Detection (runs first, always) ──────────────────────────────
  const textToScan = rawText || selectedEmotions?.join(' ') || '';
  const crisisResult = await crisisService.detectCrisis(textToScan);

  if (crisisResult.detected) {
    user.crisisCount = (user.crisisCount || 0) + 1;
    user.lastCrisisAt = new Date();
  }

  // ── 2. AI Mood Analysis ───────────────────────────────────────────────────
  let aiAnalysis = null;
  if (rawText && rawText.length > 10) {
    try {
      aiAnalysis = await openaiService.analyzeMood(rawText, selectedEmotions, moodScore);
    } catch (err) {
      logger.error('Mood analysis failed:', err.message);
      // Fallback — basic analysis from selected emotions
      aiAnalysis = {
        primaryEmotion: selectedEmotions?.[0] || 'unknown',
        emotionScores: {},
        themes: [],
        sentiment: moodScore >= 6 ? 'positive' : moodScore >= 4 ? 'neutral' : 'negative',
        summary: `Feeling ${selectedEmotions?.[0] || 'various emotions'} today.`,
      };
    }
  }

  // ── 3. Save mood entry ────────────────────────────────────────────────────
  const moodEntry = await MoodEntry.create({
    user: user._id,
    rawText,
    moodScore,
    selectedEmotions,
    aiAnalysis,
    context,
    crisisDetected: crisisResult.detected,
    crisisLevel: crisisResult.level,
    crisisKeywords: crisisResult.keywords,
  });

  // ── 4. Update user stats ──────────────────────────────────────────────────
  user.totalCheckIns += 1;
  user.updateStreak();

  // Update AI memory every 5 check-ins
  if (user.totalCheckIns % 5 === 0) {
    try {
      const recentEntries = await MoodEntry.find({ user: user._id })
        .sort({ createdAt: -1 }).limit(10);
      const newMemory = await openaiService.updateUserMemory(recentEntries, user.aiMemory);
      user.aiMemory = { ...newMemory, lastUpdated: new Date() };
    } catch (err) {
      logger.error('Memory update failed:', err.message);
    }
  }

  await user.save();

  // ── 5. Generate recommendations ───────────────────────────────────────────
  let recommendations = [];
  try {
    const aiRecs = await openaiService.generateRecommendations(
      aiAnalysis || { primaryEmotion: selectedEmotions?.[0] || 'sad', themes: [], sentiment: 'neutral' },
      user.aiMemory,
      user.preferences,
      moodScore
    );

    // Enrich with real API data (Spotify, TMDB, YouTube)
    const enriched = await Promise.all(
      aiRecs.map(rec => externalApiService.enrichRecommendation(rec))
    );

    // Save recommendations to DB
    const savedRecs = await Recommendation.insertMany(
      enriched.map(rec => ({
        user: user._id,
        moodEntry: moodEntry._id,
        moodScoreAtTime: moodScore,
        emotionTarget: rec.emotionTarget || [],
        ...rec,
      }))
    );

    moodEntry.recommendations = savedRecs.map(r => r._id);
    await moodEntry.save();
    recommendations = savedRecs;
  } catch (err) {
    logger.error('Recommendation generation failed:', err.message);
  }

  // ── 6. Response ───────────────────────────────────────────────────────────
  res.status(201).json({
    moodEntry: {
      id: moodEntry._id,
      moodScore,
      aiAnalysis,
      createdAt: moodEntry.createdAt,
    },
    recommendations,
    // If crisis detected, include the crisis response
    crisis: crisisResult.detected ? {
      detected: true,
      level: crisisResult.level,
      message: crisisResult.response.message,
      requiresAction: crisisResult.response.requiresAction,
      calmMode: crisisService.getCalmModeContent(),
    } : null,
    streak: user.streak,
    totalCheckIns: user.totalCheckIns,
  });
};

// @route  GET /api/mood/history
const getHistory = async (req, res) => {
  const { page = 1, limit = 20, days } = req.query;
  const filter = { user: req.user._id };

  if (days) {
    filter.createdAt = { $gte: new Date(Date.now() - days * 86400000) };
  }

  const entries = await MoodEntry.find(filter)
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .select('-rawText'); // don't send raw text in list view

  const total = await MoodEntry.countDocuments(filter);

  res.json({
    entries,
    totalPages: Math.ceil(total / limit),
    currentPage: parseInt(page),
    total,
  });
};

// @route  GET /api/mood/today
const getTodayMood = async (req, res) => {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const entry = await MoodEntry.findOne({
    user: req.user._id,
    createdAt: { $gte: startOfDay },
  }).sort({ createdAt: -1 });

  res.json({ entry, hasCheckedInToday: !!entry });
};

// @route  POST /api/mood/:id/followup
// User rates how they feel after consuming recommendations
const followUp = async (req, res) => {
  const { followUpScore } = req.body;
  const entry = await MoodEntry.findOneAndUpdate(
    { _id: req.params.id, user: req.user._id },
    { followUpScore, followUpAt: new Date() },
    { new: true }
  );
  if (!entry) return res.status(404).json({ error: 'Entry not found.' });
  res.json({ entry });
};

// @route  GET /api/mood/calm-mode
const calmMode = async (req, res) => {
  res.json(crisisService.getCalmModeContent());
};

module.exports = { checkIn, getHistory, getTodayMood, followUp, calmMode };
