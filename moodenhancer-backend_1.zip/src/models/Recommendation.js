const mongoose = require('mongoose');

const recommendationSchema = new mongoose.Schema({
  user:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  moodEntry: { type: mongoose.Schema.Types.ObjectId, ref: 'MoodEntry' },

  type: {
    type: String,
    enum: ['movie', 'song', 'podcast', 'game', 'audiobook', 'activity', 'meditation', 'video'],
    required: true,
  },

  title:       { type: String, required: true },
  description: String,
  reason:      String,  // "We picked this because you said you feel lonely..."
  imageUrl:    String,
  externalUrl: String,
  externalId:  String,  // Spotify ID, TMDB ID, YouTube ID
  source:      { type: String, enum: ['spotify', 'tmdb', 'youtube', 'ai_generated'] },

  // Feedback
  feedback: {
    liked:     { type: Boolean, default: null },
    consumed:  { type: Boolean, default: false }, // did they actually watch/listen?
    helpedMood:{ type: Boolean, default: null },
    ratedAt:   Date,
  },

  emotionTarget: [String], // which emotions this is meant to address
  moodScoreAtTime: Number,

}, { timestamps: true });

recommendationSchema.index({ user: 1, createdAt: -1 });
recommendationSchema.index({ user: 1, type: 1 });

module.exports = mongoose.model('Recommendation', recommendationSchema);
