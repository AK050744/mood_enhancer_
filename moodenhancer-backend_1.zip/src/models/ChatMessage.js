const mongoose = require('mongoose');

const chatMessageSchema = new mongoose.Schema({
  user:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  role:    { type: String, enum: ['user', 'assistant'], required: true },
  content: { type: String, required: true, maxlength: 3000 },

  // metadata
  crisisFlag: { type: Boolean, default: false },
  sessionId:  String, // group messages into sessions

}, { timestamps: true });

chatMessageSchema.index({ user: 1, createdAt: -1 });
chatMessageSchema.index({ user: 1, sessionId: 1 });

module.exports = mongoose.model('ChatMessage', chatMessageSchema);
