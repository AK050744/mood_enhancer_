// journalController.js
const Journal = require('../models/Journal');
const openaiService = require('../services/openaiService');
const crisisService = require('../services/crisisService');
const User = require('../models/User');

const createEntry = async (req, res) => {
  const { title, content, mood, tags } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Content is required.' });

  // Crisis check on journal entry too
  const crisis = await crisisService.detectCrisis(content);

  const user = await User.findById(req.user._id).select('name');

  // Generate AI reflection
  let aiReflection = null;
  try {
    const reflection = await openaiService.generateJournalReflection(content, user.name);
    aiReflection = { ...reflection, generatedAt: new Date() };
  } catch (err) { /* non-critical */ }

  const entry = await Journal.create({
    user: req.user._id,
    title,
    content,
    mood,
    tags,
    aiReflection,
  });

  res.status(201).json({
    entry,
    crisis: crisis.detected ? {
      level: crisis.level,
      message: crisis.response.message,
    } : null,
  });
};

const getEntries = async (req, res) => {
  const { page = 1, limit = 15 } = req.query;
  const entries = await Journal.find({ user: req.user._id })
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .select('title mood tags createdAt aiReflection');
  const total = await Journal.countDocuments({ user: req.user._id });
  res.json({ entries, totalPages: Math.ceil(total / limit), total });
};

const getEntry = async (req, res) => {
  const entry = await Journal.findOne({ _id: req.params.id, user: req.user._id });
  if (!entry) return res.status(404).json({ error: 'Not found.' });
  res.json({ entry });
};

const deleteEntry = async (req, res) => {
  await Journal.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  res.json({ message: 'Entry deleted.' });
};

module.exports = { createEntry, getEntries, getEntry, deleteEntry };
